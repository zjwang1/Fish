#pragma once

#include <easylogging/easylogging++.h>

bool initLog(int argc, const char **argv, const std::string& logFileName);
