#! /bin/bash

mkdir build_
./gen_grpc_code.sh ./route_guide.proto
cp route_guide_db.json build_

pushd build_
    cmake ..
    make -j8
popd
