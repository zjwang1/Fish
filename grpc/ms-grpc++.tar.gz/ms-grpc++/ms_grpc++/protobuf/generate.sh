#!/usr/bin/env bash

export PATH=/home/zjwang/.dep/bin
export LD_LIBRARY_PATH=/home/zjwang/.dep/lib
export LC_ALL=C
cd "$(dirname "$0")" || exit 1

# generate grpc files by manual,
# only used for some special scenes, like remote debug for Clion
# generally just generate by cmake

echo "now generate protobuf and grpc source code, protoc version: " && protoc --version

/home/zjwang/.dep/bin/protoc -I=./ --cpp_out=. --grpc_out=. --plugin=protoc-gen-grpc=/home/zjwang/.dep/bin/grpc_cpp_plugin ./greeting.proto
