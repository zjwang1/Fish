#! /bin/bash

for i in $(seq 1 4)
do
    ./client &
done
wait
