#pragma once
#include <cstddef>
static constexpr size_t S = 5000;
static constexpr size_t T = 480;
static constexpr size_t A = 16;
static constexpr size_t C = 64;
static constexpr size_t B = S * T * A / C / 30;