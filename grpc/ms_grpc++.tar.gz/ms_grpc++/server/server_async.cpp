#include <grpcpp/server.h>
#include <grpcpp/server_builder.h>
#include <mutex>
#include <vector>
#include <thread>
#include <memory>
#include <functional>

#include <greeting.grpc.pb.h>

struct ServerConfig
{
    std::string server = "0.0.0.0:23333";
    size_t async_server_threads = 4;
    size_t threads_per_cq = 1;
};

template <class RequestType, class ResponseType, class ServiceType,
          class ServerContextType>
class AsyncQpsServer
{
private:
    class ServerRpcContext
    {
    public:
        ServerRpcContext() {}
        void lock() { mu_.lock(); }
        void unlock() { mu_.unlock(); }
        virtual ~ServerRpcContext(){};
        virtual bool RunNextState(bool) = 0;  // next state, return false if done
        virtual void Reset() = 0;             // start this back at a clean state
    private:
        std::mutex mu_;
    };
    static void* tag(ServerRpcContext* func)
    {
        return static_cast<void*>(func);
    }
    static ServerRpcContext* detag(void* tag)
    {
        return static_cast<ServerRpcContext*>(tag);
    }

    class ServerRpcContextStreamingFromServerImpl final : public ServerRpcContext
    {
    public:
        using RequestFunc = std::function<void(ServerContextType*, 
                                               RequestType*,
                                               grpc::ServerAsyncWriter<ResponseType>*, 
                                               void*)>;
        using InvokeFunc = std::function<grpc::Status(RequestType*, ResponseType*)>;

        ServerRpcContextStreamingFromServerImpl(RequestFunc request_method,
                                                InvokeFunc invoke_method)
            : srv_ctx_(new ServerContextType),
              next_state_(&ServerRpcContextStreamingFromServerImpl::request_done),
              request_method_(request_method),
              invoke_method_(invoke_method),
              stream_(srv_ctx_.get())
        {
            request_method_(srv_ctx_.get(),
                            &req_,
                            &stream_,
                            AsyncQpsServer::tag(this));
        }
        ~ServerRpcContextStreamingFromServerImpl() override {}
        bool RunNextState(bool ok) override
        {
            return (this->*next_state_)(ok);
        }
        void Reset() override
        {
            srv_ctx_.reset(new ServerContextType);
            req_ = RequestType();
            stream_ = grpc::ServerAsyncWriter<ResponseType>(srv_ctx_.get());

            // Then request the method
            next_state_ = &ServerRpcContextStreamingFromServerImpl::request_done;
            request_method_(srv_ctx_.get(),
                            &req_,
                            &stream_,
                            AsyncQpsServer::tag(this));
        }

    private:
        bool request_done(bool ok)
        {
            if (!ok)
            {
                return false;
            }
            // invoke the method
            // Call the RPC processing function
            grpc::Status status = invoke_method_(&req_, &response_);

            next_state_ = &ServerRpcContextStreamingFromServerImpl::write_done;
            stream_.Write(response_, AsyncQpsServer::tag(this));
            return true;
        }

        bool write_done(bool ok)
        {
            if (ok)
            {
                // Do another write!
                // next_state_ is unchanged
                stream_.Write(response_, AsyncQpsServer::tag(this));
            }
            else
            {  // must be done so let's finish
                next_state_ = &ServerRpcContextStreamingFromServerImpl::finish_done;
                stream_.Finish(grpc::Status::OK, AsyncQpsServer::tag(this));
            }
            return true;
        }

        bool finish_done(bool /*ok*/) { return false; /*reset the context*/ }

        std::unique_ptr<ServerContextType> srv_ctx_;
        RequestType req_;
        ResponseType response_;
        bool (ServerRpcContextStreamingFromServerImpl::*next_state_)(bool);
        RequestFunc request_method_;
        InvokeFunc invoke_method_;
        grpc::ServerAsyncWriter<ResponseType> stream_;
    };
private:
    std::vector<std::thread> threads_;
    std::unique_ptr<grpc::Server> server_;
    std::vector<std::unique_ptr<grpc::ServerCompletionQueue>> srv_cqs_;
    std::vector<size_t> cq_;
    ServiceType async_service_;
    std::vector<std::unique_ptr<ServerRpcContext>> contexts_;

    struct PerThreadShutdownState {
        mutable std::mutex mutex;
        bool shutdown;
        PerThreadShutdownState() : shutdown(false) {}
    };

    std::vector<std::unique_ptr<PerThreadShutdownState>> shutdown_state_;

public:
    using RequestStreamFromServerFunc = std::function<void(ServiceType*,                            // ie. Service by proto file
                                                           ServerContextType*,                      // ie. grpc::ServerContext
                                                           RequestType*,                            // ie. Request Type by proto file
                                                           grpc::ServerAsyncWriter<ResponseType>*,  // ie. Response stream writer by proto file
                                                           grpc::CompletionQueue*,                  // Grpc async api 
                                                           grpc::ServerCompletionQueue*,            // Grpc async api
                                                           void*)>;                                 // A tag for a session

    using RpcProcessFunc = std::function<grpc::Status(RequestType*, ResponseType*)>;                // A callback for process
    AsyncQpsServer(const ServerConfig& config,
                   RequestStreamFromServerFunc request_streaming_from_server_function,
                   RpcProcessFunc process_rpc)
    {
        auto builder = std::make_unique<grpc::ServerBuilder>();
        builder->AddListeningPort(config.server, grpc::InsecureServerCredentials());
        builder->SetMaxSendMessageSize(1 << 31);
        builder->RegisterService(&async_service_);
        size_t num_threads = config.async_server_threads;
        const size_t def = 1;
        size_t tpc = std::max(def, config.threads_per_cq);  // 1 if unspecified
        size_t num_cqs = (num_threads + tpc - 1) / tpc;   // ceiling operator
        for (size_t i = 0; i < num_cqs; i++)
        {
            srv_cqs_.emplace_back(builder->AddCompletionQueue());
        }
        for (size_t i = 0; i < num_threads; i++)
        {
            cq_.emplace_back(i % srv_cqs_.size());
        }
        server_ = builder->BuildAndStart();

        auto process_rpc_bound = std::bind(process_rpc, std::placeholders::_1, std::placeholders::_2);
        for (size_t i = 0; i < num_cqs; i++)
        {
            auto request_streaming_from_server = std::bind(request_streaming_from_server_function, 
                                                           &async_service_,
                                                           std::placeholders::_1, 
                                                           std::placeholders::_2,
                                                           std::placeholders::_3,
                                                           srv_cqs_[i].get(),
                                                           srv_cqs_[i].get(),
                                                           std::placeholders::_4);
            contexts_.emplace_back(new ServerRpcContextStreamingFromServerImpl(request_streaming_from_server, process_rpc_bound));
        }
        for (int i = 0; i < num_threads; i++)
        {
            shutdown_state_.emplace_back(new PerThreadShutdownState());
            threads_.emplace_back(&AsyncQpsServer::ThreadFunc, this, i);
        }
    }

    ~AsyncQpsServer()
    {
        for (auto ss = shutdown_state_.begin(); ss != shutdown_state_.end(); ++ss)
        {
            std::lock_guard<std::mutex> lock((*ss)->mutex);
            (*ss)->shutdown = true;
        }
        // TODO(vjpai): Remove the following deadline and allow full proper
        // shutdown.
        server_->Shutdown(std::chrono::system_clock::now() + std::chrono::seconds(3));
        for (auto cq = srv_cqs_.begin(); cq != srv_cqs_.end(); ++cq)
        {
            (*cq)->Shutdown();
        }
        for (auto thr = threads_.begin(); thr != threads_.end(); thr++)
        {
            thr->join();
        }
        for (auto cq = srv_cqs_.begin(); cq != srv_cqs_.end(); ++cq)
        {
            bool ok;
            void* got_tag;
            while ((*cq)->Next(&got_tag, &ok))
            ;
        }
    }
private:
    void ThreadFunc(int thread_idx)
    {
        // Wait until work is available or we are shutting down
        bool ok;
        void* got_tag;
        if (!srv_cqs_[cq_[thread_idx]]->Next(&got_tag, &ok))
        {
            return;
        }
        ServerRpcContext* ctx;
        std::mutex* mu_ptr = &shutdown_state_[thread_idx]->mutex;
        do
        {
            ctx = detag(got_tag);
            // The tag is a pointer to an RPC context to invoke
            // Proceed while holding a lock to make sure that
            // this thread isn't supposed to shut down
            mu_ptr->lock();
            if (shutdown_state_[thread_idx]->shutdown)
            {
                mu_ptr->unlock();
                return;
            }
        }
        while (srv_cqs_[cq_[thread_idx]]->DoThenAsyncNext(
            [&, ctx, ok, mu_ptr]() {
                ctx->lock();
                if (!ctx->RunNextState(ok))
                {
                    ctx->Reset();
                }
                ctx->unlock();
                mu_ptr->unlock();
            },
            &got_tag, 
            &ok, 
            gpr_inf_future(GPR_CLOCK_REALTIME)));
    }
};

static grpc::Status ProcessSimpleRPC(grpc::example::RequestSubscribe *request,
                                     grpc::example::ReplyGreeting *response)
{
  
  // We are done using the request. Clear it to reduce working memory.
  // This proves to reduce cache misses in large message size cases.
  request->Clear();
  std::string s(2 * 1024 * 1024, 'a');
  response->set_message(s);
  return grpc::Status::OK;
}

struct ProcessFunctor
{

};

int main()
{
    using AsyncQpsServerTest = AsyncQpsServer<grpc::example::RequestSubscribe,
                                              grpc::example::ReplyGreeting,
                                              grpc::example::GreetingService::AsyncService,
                                              grpc::ServerContext>;
    const ServerConfig config;
    std::cout << "config.server: " << config.server << "\n";
    auto test = std::make_unique<AsyncQpsServerTest>(config,
                                                     &grpc::example::GreetingService::AsyncService::RequestSubscribeGreetingBySecond,
                                                     ProcessSimpleRPC);
    for(;;)
    {
        std::this_thread::sleep_for(std::chrono::seconds(5));
    }
    return 0;
}