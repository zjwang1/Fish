#pragma once

#include <greeting.grpc.pb.h>
#include <grpc/grpc.h>
#include <grpcpp/channel.h>

#include <memory>

#include "performance.h"

class GreetingClient 
{
public:
    GreetingClient(const GreetingClient &) = delete;

    GreetingClient(GreetingClient &&) = delete;

    GreetingClient &operator=(const GreetingClient &) = delete;

    GreetingClient &operator=(GreetingClient &&) = delete;

    static GreetingClient &GetInstance() 
    {
        static GreetingClient kSingleInstance;
        return kSingleInstance;
    }

    bool Init(const std::string &name, const std::string &server);

    void Run();

    void Stop();

private:
    GreetingClient() = default;

    virtual ~GreetingClient() = default;

public:
    std::atomic_bool running_{false};

    std::unique_ptr<::grpc::example::GreetingService::Stub> stub_;
    ::grpc::ClientContext context_{};
    std::unique_ptr<
        ::grpc::ClientReader<::grpc::example::ReplyGreeting>>
        stream_{};
    Performance performance_{};
    std::string name_{};
};
