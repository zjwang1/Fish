#include "async_stream_session.h"

#include "async_stream_server.h"
#include "log_helper.h"

bool GreetingSession::Init() 
{
    GreetingServer::GetInstance().greeting_async_service_.RequestSubscribeGreetingBySecond(
        &server_context_,
        &subscribe_stream,
        GreetingServer::GetInstance().completion_queue_call_.get(),
        GreetingServer::GetInstance().completion_queue_notification_.get(),
        reinterpret_cast<void*>(session_id_ << GRPC_EVENT_BIT_LENGTH | GRPC_EVENT_CONNECTED));
    return true;
}

void GreetingSession::Process(GrpcEvent event) 
{
    LOG(DEBUG) << "session_id_: " << session_id_ << ", current status: " << status_ << ", event: " << event;
    switch (event) 
    {
        case GRPC_EVENT_CONNECTED:
            subscribe_stream.Read(
                &request_,
                reinterpret_cast<void*>(session_id_ << GRPC_EVENT_BIT_LENGTH | GRPC_EVENT_READ_DONE));
            status_ = GrpcSessionStatus::READY_TO_WRITE;
            GreetingServer::GetInstance().AddSession();
            return;
        case GRPC_EVENT_READ_DONE:
            LOG(DEBUG) << "session_id_: " << session_id_ << ", new request: " << request_.ShortDebugString();
            performance_.setName(name_);
            performance_.add(std::chrono::duration_cast<std::chrono::nanoseconds>(
                                 std::chrono::system_clock::now().time_since_epoch())
                                 .count() -
                             request_.current_nanosecond());
            name_ = request_.name();
            subscribe_stream.Read(
                &request_,
                reinterpret_cast<void*>(session_id_ << GRPC_EVENT_BIT_LENGTH | GRPC_EVENT_READ_DONE));
            Reply();
            return;
        case GRPC_EVENT_WRITE_DONE:
            if (!message_queue_.empty()) 
            {
                status_ = GrpcSessionStatus::WAIT_WRITE_DONE;
                subscribe_stream.Write(
                    *message_queue_.front(),
                    reinterpret_cast<void*>(session_id_ << GRPC_EVENT_BIT_LENGTH | GRPC_EVENT_WRITE_DONE));
                // message_pool_.emplace_back(message_queue_.front());
                message_queue_.pop_front();
            } else
            {
                status_ = GrpcSessionStatus::READY_TO_WRITE;
            }
            return;
        default:
            LOG(DEBUG) << "session_id_: " << session_id_ << ", unhandled event: " << event;
            return;
    }
}

void GreetingSession::Reply() 
{
    if (status_ != GrpcSessionStatus::READY_TO_WRITE && status_ != GrpcSessionStatus::WAIT_WRITE_DONE) 
    {
        return;
    }
    std::shared_ptr<::grpc::example::ReplyGreeting> new_message = nullptr;
    auto stock_num = request_.stock_num();
    auto time_point_num = request_.time_point_num();
    auto attr_num = request_.attr_num();
    new_message = std::make_shared<::grpc::example::ReplyGreeting>();
    new_message->set_message(name_ + ": " + std::to_string(++reply_times_));

    new_message->set_current_nanosecond(std::chrono::duration_cast<std::chrono::nanoseconds>(
                                        std::chrono::system_clock::now().time_since_epoch())
                                        .count());
    new_message->set_stock_num(stock_num);
    new_message->set_time_point_num(time_point_num);
    new_message->set_attr_num(attr_num);
    new_message->mutable_res()->Resize(stock_num * time_point_num * attr_num, 1.0);
    for (size_t i = 0; i < stock_num * time_point_num * attr_num; ++i)
    {
        new_message->set_res(i, i * 1.0);
    }
    if (status_ == GrpcSessionStatus::READY_TO_WRITE) 
    {
        status_ = GrpcSessionStatus::WAIT_WRITE_DONE;
        subscribe_stream.Write(
            *new_message,
            reinterpret_cast<void*>(session_id_ << GRPC_EVENT_BIT_LENGTH | GRPC_EVENT_WRITE_DONE));
    } else 
    {
        message_queue_.emplace_back(new_message);
    }
}

void GreetingSession::Finish() 
{
    if (status_ == GrpcSessionStatus::WAIT_CONNECT) { return; }
    subscribe_stream.Finish(
        ::grpc::Status::CANCELLED,
        reinterpret_cast<void*>(session_id_ << GRPC_EVENT_BIT_LENGTH | GRPC_EVENT_FINISHED));
}