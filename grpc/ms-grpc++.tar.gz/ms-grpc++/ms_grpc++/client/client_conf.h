#pragma once
#include <functional>
struct ClientConf
{
    using QuitConditionFunc = std::function<bool()>;
};
