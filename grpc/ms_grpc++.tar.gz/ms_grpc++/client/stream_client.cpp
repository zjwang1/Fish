#include "stream_client.h"

#include <grpcpp/grpcpp.h>
#include <grpcpp/create_channel.h>
#include <grpcpp/security/credentials.h>

#include <thread>

#include "log_helper.h"
#include "timestamp.h"

using grpc::Channel;

bool GreetingClient::Init(const std::string &name, const std::string &server) {
    name_ = name;
    performance_.setName(name_);
    ::grpc::ChannelArguments args;
    args.SetMaxReceiveMessageSize(1 << 31);
    stub_ = ::grpc::example::GreetingService::NewStub(
        grpc::CreateCustomChannel(server, grpc::InsecureChannelCredentials(), args));
    return true;
}

void GreetingClient::Run() 
{
    running_ = true;
    grpc::example::RequestSubscribe request;
    stream_ = stub_->SubscribeGreetingBySecond(&context_, request);

    std::thread thread_for_reply{[this] {
        LOG(INFO) << "thread_for_reply run";
        grpc::example::ReplyGreeting reply;
        auto st = getns();
        size_t cnt = 0;
        while (stream_->Read(&reply)) 
        {
            // performance_.add(std::chrono::duration_cast<std::chrono::nanoseconds>(
            //                      std::chrono::system_clock::now().time_since_epoch())
            //                      .count() -
            //                  reply.current_nanosecond());
            auto stock_num = reply.stock_num();
            auto time_point_num = reply.time_point_num();
            auto attr_num = reply.attr_num();
            for (size_t i = 0; i < stock_num * time_point_num * attr_num; ++i)
                assert(i * 1.0 == reply.res(i));
            if (++cnt >= 50)
                break;
            // LOG(DEBUG) << "receive reply: " << reply.ByteSizeLong();
            // ++cnt;
        }
        auto ed = getns();
        LOG(INFO) << "thread_for_reply stop, recv: " << cnt << " msgs, use:" << (ed - st) / 1000 / 1000 << "ms.\n";
    }};
    if (thread_for_reply.joinable()) { thread_for_reply.join(); }
}

void GreetingClient::Stop() 
{
    if (!running_) { return; }
    running_ = false;
    LOG(INFO) << "context_->TryCancel() begin";
    context_.TryCancel();
    LOG(INFO) << "context_->TryCancel() end";
}
