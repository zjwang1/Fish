#! /bin/bash

for i in $(seq 1 8)
do
    ./client &
done
wait
