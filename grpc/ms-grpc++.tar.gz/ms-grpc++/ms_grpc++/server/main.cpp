#include "async_stream_server.h"
#include "log_helper.h"

void handler(int sig) {
    std::cout << "get signal: " << sig << std::endl;
    GreetingServer::GetInstance().Stop();
}

int main(int argc, const char **argv) {
    signal(SIGTERM, handler);
    signal(SIGINT, handler);

    if (!initLog(argc, argv, "server")) {
        std::cout << "init log failed" << std::endl;
        return 1;
    }

    try {
        if (!GreetingServer::GetInstance().Init("0.0.0.0:6666")) {
            LOG(INFO) << "init failure";
            return 1;
        }
        GreetingServer::GetInstance().Run();
    } catch (std::exception &e) {
        LOG(INFO) << "exception: " << e.what();
        return 1;
    }

    return 0;
}
