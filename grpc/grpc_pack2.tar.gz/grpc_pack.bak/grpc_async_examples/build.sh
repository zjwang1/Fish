#! /bin/bash

mkdir -p build_
./gen_grpc_code.sh ./helloworld.proto

pushd build_
    cmake ..
    make -j8
popd

