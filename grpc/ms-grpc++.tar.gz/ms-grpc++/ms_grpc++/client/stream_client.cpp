#include "stream_client.h"

#include <grpcpp/grpcpp.h>
#include <grpcpp/create_channel.h>
#include <grpcpp/security/credentials.h>

#include <thread>

#include "log_helper.h"
#include "timestamp.h"

using grpc::Channel;

bool GreetingClient::Init(const std::string &name, const std::string &server) {
    name_ = name;
    performance_.setName(name_);
    ::grpc::ChannelArguments args;
    args.SetMaxReceiveMessageSize(1 << 31);
    stub_ = ::grpc::example::GreetingService::NewStub(
        grpc::CreateCustomChannel(server, grpc::InsecureChannelCredentials(), args));
    return true;
}

void GreetingClient::Run() 
{
    running_ = true;
    stream_ = stub_->SubscribeGreetingBySecond(&context_);

    std::thread thread_for_reply{[this] {
        LOG(INFO) << "thread_for_reply run";
        ::grpc::example::ReplyGreeting reply;
        auto st = getns();
        size_t cnt = 0;
        while (stream_->Read(&reply)) 
        {
            // performance_.add(std::chrono::duration_cast<std::chrono::nanoseconds>(
            //                      std::chrono::system_clock::now().time_since_epoch())
            //                      .count() -
            //                  reply.current_nanosecond());
            auto stock_num = reply.stock_num();
            auto time_point_num = reply.time_point_num();
            auto attr_num = reply.attr_num();
            for (size_t i = 0; i < stock_num * time_point_num * attr_num; ++i)
                assert(i * 1.0 == reply.res(i));
            if (++cnt >= 50)
                break;
            // LOG(DEBUG) << "receive reply: " << reply.ByteSizeLong();
            // ++cnt;
        }
        auto ed = getns();
        LOG(INFO) << "thread_for_reply stop, recv: " << cnt << " msgs, use:" << (ed - st) / 1000 / 1000 << "ms.\n";
    }};

    std::thread thread_for_request{[this] {
        LOG(INFO) << "thread_for_request run";
        uint64_t increase_name{0};
        ::grpc::example::RequestSubscribe request;

        // while (running_) {
        //     request.set_name(name_);
        //     request.set_current_nanosecond(std::chrono::duration_cast<std::chrono::nanoseconds>(
        //                                        std::chrono::system_clock::now().time_since_epoch())
        //                                        .count());
        //     if (!stream_->Write(request)) {
        //         LOG(INFO) << "session closed";
        //         break;
        //     }
        //     std::this_thread::sleep_for(std::chrono::milliseconds(1000));
        // }
        for (size_t i = 0; i < 50; ++i)
        {
            request.set_name(name_);
            request.set_current_nanosecond(std::chrono::duration_cast<std::chrono::nanoseconds>(
                                               std::chrono::system_clock::now().time_since_epoch())
                                               .count());
            request.set_stock_num(100);
            request.set_time_point_num(240);
            request.set_attr_num(12);
            if (!stream_->Write(request)) {
                LOG(INFO) << "session closed";
                break;
            }
        }
        LOG(INFO) << "thread_for_request stop";
    }};

    if (thread_for_reply.joinable()) { thread_for_reply.join(); }
    if (thread_for_request.joinable()) { thread_for_request.join(); }
}

void GreetingClient::Stop() 
{
    if (!running_) { return; }
    running_ = false;
    LOG(INFO) << "context_->TryCancel() begin";
    context_.TryCancel();
    LOG(INFO) << "context_->TryCancel() end";
}
