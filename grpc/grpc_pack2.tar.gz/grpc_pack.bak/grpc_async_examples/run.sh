#! /bin/bash

type=${1:-"server"}

if [[ $type == "server" ]];then
    pushd build_
        export LD_LIBRARY_PATH=/home/zjwang/.dep/lib
        ./server
    popd
else
    pushd build_
        export LD_LIBRARY_PATH=/home/zjwang/.dep/lib
        ./client
    popd
fi
